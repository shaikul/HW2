package com.company;


public class Main {

    public static void main(String[] args) {
        weahter();
        System.out.println(sitHome());
        weahterTwo();
        System.out.println(sitHome());
        weahterThree();
        System.out.println(sitHome());
    }

        public static void weahter() {
            int age = 30;
            int temperature = 20;

            if (age < 20 && temperature >= 0 || temperature > 28) {
                System.out.println("Можно идти гулять");
            }
            if (age > 45 && temperature > -10 || temperature < 25) {
                System.out.println("Можно идти гулять");
            } else if (age > 20 || age < 45 && temperature > -20 || temperature < 30) {
                System.out.println("Можно идти гулять");
            }
        }

    public static void weahterTwo() {
        int age = 15;
        int temperature = 10;

        if (age < 20 && temperature >= 0 || temperature > 28) {
            System.out.println("Можно идти гулять");
        }
        if (age > 45 && temperature > -10 || temperature < 25) {
            System.out.println("Можно идти гулять");
        } else if (age > 20 || age < 45 && temperature > -20 || temperature < 30) {
            System.out.println("Можно идти гулять");
        }
    }
    public static void weahterThree() {
        int age = 55;
        int temperature = -22;

        if (age < 20 && temperature >= 0 || temperature > 28) {
            System.out.println("Можно идти гулять");
        }
        if (age > 45 && temperature > -10 || temperature < 25) {
            System.out.println("Можно идти гулять");
        } else if (age > 20 || age < 45 && temperature > -20 || temperature < 30) {
            System.out.println("Можно идти гулять");
        }
    }
    public static String sitHome(){
        return "Оставайтесь дома ";


    }
    }


